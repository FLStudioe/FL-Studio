## Rename Bot Pro Android

Un bot de código abierto para cambiar el nombre de archivos de Telegram hecho por Cursos Pro Android

---
Cambie el nombre de los archivos de Telegram con soporte permanente de miniaturas

* Con detección automática de las extensiones de los archivos


### Instalación


### ¡Puede tocar el botón Implementar en Heroku a continuación para implementar directamente en Heroku!
[![Implementar](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/cursosproandroid/RenameBotProAndroid)

### Implementa el bot en tu vps
```sh
git clone https://github.com/cursosproandroid/RenameBotProAndroid
cd RenameBotProAndroid
virtualenv -p python3 VENV
. ./VENV/bin/activate
pip install -r requirements.txt
# <Create config.py appropriately>
python3 -m tobrot
```


#### Para consultas y soporte, contacte a [Skueletor](https://telegram.dog/DKzippO)

## Créditos:

* [Cursos Pro Android](https://t.me/joinchat/VDY6seEnkeKdZNRM) 
